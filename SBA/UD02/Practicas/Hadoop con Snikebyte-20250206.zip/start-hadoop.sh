#!/bin/bash

# Formatear el sistema de archivos HDFS (solo la primera vez)
$HADOOP_HOME/bin/hdfs namenode -format

# Iniciar NameNode y DataNode
$HADOOP_HOME/sbin/start-dfs.sh

# Mantener el contenedor en ejecución
/bin/bash